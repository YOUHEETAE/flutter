package com.hospital.service;

import com.hospital.dao.HospitalDAO;
import com.hospital.dto.HospitalDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class HospitalServiceImpl implements HospitalService {

    private final HospitalDAO hospitalDAO;
    private final double EARTH_RADIUS = 6371; // 지구 반지름 (단위: km)

    @Autowired
    public HospitalServiceImpl(HospitalDAO hospitalDAO) {
        this.hospitalDAO = hospitalDAO;
    }

    @Override
    public List<HospitalDTO> getHospitals(String sub, double userLat, double userLng, double radius, String emergencyRoomInfo, Integer parkingInfo) {
        
        List<HospitalDTO> hospitals = hospitalDAO.getAllHospitals(sub);
        
        // 주차 및 응급실 필터링 추가
        List<HospitalDTO> filteredHospitals = hospitals.stream()
                .filter(hospital -> filterByEmergency(hospital, emergencyRoomInfo))   // 응급실 필터링
                .filter(hospital -> filterByParking(hospital, parkingInfo))       // 주차 필터링
                .filter(hospital -> calculateDistance(userLat, userLng, hospital.getCoordinateY(), hospital.getCoordinateX()) <= radius)  // 거리 필터링
                .collect(Collectors.toList());

        return filteredHospitals;
    }

    private boolean filterByEmergency(HospitalDTO hospital, String emergencyRoomInfo) {
        // 'emergencyRoomInfo'가 null, 빈 문자열, 또는 "0"일 경우 필터링하지 않음
        if (emergencyRoomInfo == null || emergencyRoomInfo.isEmpty() || emergencyRoomInfo.equals("0")) {
            return true;  // 필터링 안 함 (응급실 여부 관계없이 모두 포함)
        }
        // '1'이 들어왔을 경우에만 필터링 적용
        if ("1".equals(emergencyRoomInfo)) {
            return !hospital.getEmergency_available().equals("N");  // 응급실이 "N"이 아니면 통과
        }
        return true;  // 필터링 안 함
    }

    private boolean filterByParking(HospitalDTO hospital, Integer parkingInfo) {
        // 'parkingInfo'가 null 또는 0일 경우 필터링하지 않음
        if (parkingInfo == null || parkingInfo == 0) {
            return true;  // 필터링 안 함 (주차 여부 관계없이 모두 포함)
        }
        // '1'이 들어왔을 경우에만 필터링 적용
        if (parkingInfo == 1) {
            Integer parkAvailable = hospital.getPark_available();
            return parkAvailable != null && parkAvailable != 0;  // 주차 가능 병원만 통과 (0이 아니어야 함)
        }
        return true;  // 필터링 안 함
    }

    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return EARTH_RADIUS * c; // km 단위
    }
}