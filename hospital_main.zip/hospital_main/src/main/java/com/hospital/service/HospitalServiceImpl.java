package com.hospital.service;

import com.hospital.dao.HospitalDAO;
import com.hospital.dto.HospitalDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HospitalServiceImpl implements HospitalService {

    private final HospitalDAO hospitalDAO;
   

    @Autowired
    public HospitalServiceImpl(HospitalDAO hospitalDAO) {
        this.hospitalDAO = hospitalDAO;
    }

    @Override
    public List<HospitalDTO> getHospitals(String sub, double userLat, double userLng, double radius) {
    	
    	private static final double EARTH_RADIUS = 6371; // 지구 반지름 (단위: km)
    	
    	List<HospitalDTO> hospitals = getSubHospitals(sub);
    	
    	List<HospitalDTO> nearbyHospitals = hospitals.stream()
                .filter(hospital -> calculateDistance(userLat, userLng, hospital.getLatitude(), hospital.getLongitude()) <= radius)
                .collect(Collectors.toList());

            return nearbyHospitals;
    	
        return hospitalDAO.getAllHospitals(sub); // DAO에서 데이터 가져오기
    }
    
    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return EARTH_RADIUS * c; // km 단위
    }
    // 병원 타입에 맞는 병원 목록을 DB에서 가져오는 예시 메서드
    private List<HospitalDTO> getSubHospitals(String sub) {
        // DB에서 병원 목록을 가져오는 로직
        // 예시로 타입에 맞는 병원 목록을 반환한다고 가정
        return hospitalDAO.findByType(sub); 
    }
}