export default [{
    id : 0,
    title: "내과",
    image: "fa-solid fa-stethoscope",
    content: "Internal Medicine"
    },
    {
    id : 1,
    title: "외과",
    image: "fa-solid fa-heart",
    content: "Surgery"
    },
    {
    id : 2,
    title: "신경과",
    image: "fa-solid fa-brain",
    content: "Neurology"
    },
    {
    id : 3,
    title: "정형외과",
    image: "fa-solid fa-bone",
    content: "Orthopedics"
    },
    {
    id : 4,
    title: "안과",
    image: "fa-solid fa-eye",
    content: "Ophthalmology"
    },
    {
    id : 5,
    title: "소화기내과",
    image: "fa-solid fa-head-side-cough",
    content: "Gastroenterology"
    },
    {
    id : 6,
    title: "호흡기내과",
    image: "fa-solid fa-circle-radiation",
    content: "Respiratory Medicine"
    },
    {
    id : 7,
    title: "심장내과",
    image: "fa-solid fa-skull",
    content: "Cardiology"
}];