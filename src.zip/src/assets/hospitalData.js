export default [{
    id : 0,
    name: "연세한결소아청소년과의원1",
    department: "소아청소년과",
    address: "서울특별시 강서구 마곡동",
    content: "09:00 - 18:30 ",
    img: "src/assets/run.jpg",
    lat: 37.3508865,
    lng: 127.1094943
    },
    {
    id : 1,
    name: "연세한결소아청소년과의원2",
    department: "소아청소년과",
    address: "서울특별시 강서구 마곡동",
    content: "09:00 - 18:30 ",
    img: "src/assets/run.jpg",
    lat: 37.3511826,
    lng: 127.1095077
    },
    {
    id : 2,
    name: "연세한결소아청소년과의원3",
    department: "소아청소년과",
    address: "서울특별시 강서구 마곡동",
    content: "09:00 - 18:30 ",
    img: "src/assets/run.jpg",
    lat: 127.1083309,
    lng: 127.1083309
    },
    {
    id : 3,
    name: "연세한결소아청소년과의원4",
    department: "소아청소년과",
    address: "서울특별시 강서구 마곡동",
    content: "09:00 - 18:30 ",
    img: "src/assets/run.jpg",
    lat: 37.3496874,
    lng: 127.1103865
    },
    {
    id : 4,
    name: "연세한결소아청소년과의원5",
    department: "소아청소년과",
    address: "서울특별시 강서구 마곡동",
    content: "09:00 - 18:30 ",
    img: "src/assets/run.jpg",
    lat: 37.3503551,
    lng: 127.1066794
    },
    {
    id : 5,
    name: "연세한결소아청소년과의원6",
    department: "소아청소년과",
    address: "서울특별시 강서구 마곡동",
    content: "09:00 - 18:30 ",
    img: "src/assets/run.jpg",
    lat: 37.3503901,
    lng: 127.1113450
}];